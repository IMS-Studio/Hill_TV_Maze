import "./App.css";
import Show from "./Show";

const SHOW_ID = 41748;

function App() {
  return (
    <div className="App">
      <Show show_id={SHOW_ID} />
    </div>
  );
}

export default App;
